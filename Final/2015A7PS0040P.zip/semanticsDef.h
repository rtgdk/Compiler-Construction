/*
Rohit Lodha
2015A7PS0040P
*/
#ifndef SYMBOLTABLEDEF
#define SYMBOLTABLEDEF

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <stdbool.h>

#include "astDef.h"
#include "symbolTableDef.h"
#include "parserDef.h"

int saerror;

#endif
